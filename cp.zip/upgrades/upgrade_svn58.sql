RENAME TABLE `bruteforce` TO `cp_bruteforce`;
RENAME TABLE `links` TO `cp_links`;
RENAME TABLE `query_log` TO `cp_querylog`;
RENAME TABLE `server_status` TO `cp_server_status`;
